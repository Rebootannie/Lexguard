"""AI Clause Extraction panel with AgGrid risk-colored table and native alert box."""
import streamlit as st
import pandas as pd

try:
    from st_aggrid import AgGrid, GridOptionsBuilder, JsCode, GridUpdateMode
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False

def _render_aggrid(df):
    """Render the clause table using AgGrid with risk-colored rows."""
    row_style_jscode = JsCode("""
    function(params) {
        if (params.data._risk === 'high') {
            return {
                'color': '#e74c3c',
                'backgroundColor': 'rgba(214, 39, 40, 0.12)',
                'fontWeight': '700',
                'borderLeft': '3px solid #d62728'
            };
        } else if (params.data._risk === 'medium') {
            return {
                'color': '#f39c12',
                'backgroundColor': 'rgba(255, 165, 0, 0.08)',
                'fontWeight': '500',
                'borderLeft': '3px solid #e67e22'
            };
        } else {
            return {
                'color': '#95a5a6',
                'backgroundColor': 'rgba(44, 160, 44, 0.03)',
                'borderLeft': '3px solid transparent'
            };
        }
    };
    """)

    display_df = df[["Clause", "Extracted Value", "Risk Level", "Playbook Match"]]

    gb = GridOptionsBuilder.from_dataframe(display_df)
    gb.configure_default_column(resizable=True, filterable=False, sortable=False)
    gb.configure_column("Clause", width=140)
    gb.configure_column("Extracted Value", width=140)
    gb.configure_column("Risk Level", width=120)
    gb.configure_column("Playbook Match", width=110)

    grid_options = gb.build()
    grid_options["getRowStyle"] = row_style_jscode
    grid_options["domLayout"] = "autoHeight"

    AgGrid(
        df[["Clause", "Extracted Value", "Risk Level", "Playbook Match", "_risk"]],
        gridOptions=grid_options,
        allow_unsafe_jscode=True,
        theme="streamlit",
        height=280,
        update_mode=GridUpdateMode.NO_UPDATE,
        columns_auto_size_mode=1,
    )


def _render_html_table(df):
    """Fallback: render standard dataframe if AgGrid fails."""
    st.dataframe(df[["Clause", "Extracted Value", "Risk Level", "Playbook Match"]], use_container_width=True)


def render():
    """Render clause extraction panel with AgGrid and native alert."""
    st.subheader("🤖 AI Clause Extraction & Risk Flags")
    
    is_analyzed = st.session_state.get("analysis_complete", False)
    ml_results = st.session_state.get("ml_results", [])
    
    if not is_analyzed or not ml_results:
        st.info("Upload and analyze a document to view extracted clauses and risk flags.")
        return

    # Convert ML results to the format expected by the table
    clause_data = []
    standard_count = 0
    medium_count = 0
    high_count = 0
    
    # Need access to original paragraphs for the text snippet
    paragraphs = st.session_state.get("extracted_paragraphs", [])
    
    for idx, r in enumerate(ml_results):
        clause_type = r.get("clause_type", "Unknown").replace("-", " ").title()
        risk_level = r.get("risk_level", "Standard")
        
        # Get the actual text snippet
        para_text = paragraphs[idx] if idx < len(paragraphs) else f"Paragraph {idx + 1}"
        # Clean up text and truncate
        snippet = para_text.replace("\n", " ").strip()
        if len(snippet) > 80:
            snippet = snippet[:80] + "..."
            
        # Simple heuristic mapping for display
        if risk_level == "High":
            high_count += 1
            display_risk = "🔴 HIGH RISK"
            pb_match = "✗ Mismatch"
            risk_val = "high"
        elif risk_level == "Medium":
            medium_count += 1
            display_risk = "⚠️ Medium"
            pb_match = "~ Partial"
            risk_val = "medium"
        else:
            standard_count += 1
            display_risk = "✅ Standard"
            pb_match = "✓ Match"
            risk_val = "standard"
            
        clause_data.append({
            "Clause": clause_type,
            "Extracted Value": snippet,
            "Risk Level": display_risk,
            "Playbook Match": pb_match,
            "_risk": risk_val
        })
    
    df = pd.DataFrame(clause_data)

    # Extraction summary pills using native columns
    c1, c2, c3 = st.columns(3)
    with c1:
        st.success(f"✅ {standard_count} Standard")
    with c2:
        st.warning(f"⚠️ {medium_count} Medium Risk")
    with c3:
        st.error(f"🔴 {high_count} High Risk")

    # Render data grid
    if HAS_AGGRID:
        _render_aggrid(df)
    else:
        _render_html_table(df)

    st.write("")

    # If high risk found, show generic alert for the first one
    if high_count > 0:
        high_risk_clause = next((c for c in clause_data if c["_risk"] == "high"), None)
        if high_risk_clause:
            st.error(f"**CRITICAL: Playbook Mismatch Detected**\n\n{high_risk_clause['Clause']} — This clause represents a high risk based on playbook standards.", icon="🚨")
            
            with st.container(border=True):
                st.caption("Action Required: Escalate to Legal for renegotiation before signing.")
