"""Top-row KPI metric cards using true Streamlit native components."""
import streamlit as st
import plotly.graph_objects as go


def render():
    """Render the top row of 3 KPI metric cards using st.metric."""
    st.markdown("### Dashboard Overview")
    
    # Check if analysis is complete
    is_analyzed = st.session_state.get("analysis_complete", False)
    ml_results = st.session_state.get("ml_results", [])
    
    if is_analyzed and ml_results:
        st.caption("Last updated: Just now")
        high_risk_count = sum(1 for r in ml_results if r.get("risk_level") == "High")
        medium_risk_count = sum(1 for r in ml_results if r.get("risk_level") == "Medium")
        
        total_analyzed = st.session_state.get("total_documents_analyzed", 1)
        
        # Simple dummy compliance score calculation: start at 100, -10 per high risk, -5 per medium risk
        score = 100
        for r in ml_results:
            if r.get("risk_level") == "High":
                score -= 10
            elif r.get("risk_level") == "Medium":
                score -= 5
        score = max(0, score) # don't go below 0
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric(label="📊 DOCUMENTS", value=str(total_analyzed), delta="Total across session")
        with col2:
            st.metric(label="⚠️ HIGH RISKS", value=str(high_risk_count), delta=f"{high_risk_count} found")
            
    else:
        st.caption("Waiting for document upload...")
        col1, col2 = st.columns(2)
        with col1:
            st.metric(label="📊 DOCUMENTS", value="0")
        with col2:
            st.metric(label="⚠️ HIGH RISKS", value="0")
