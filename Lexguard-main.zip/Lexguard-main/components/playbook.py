"""Playbook RAG comparison panel using native Streamlit containers and columns."""
import streamlit as st


def render():
    """Render the Playbook RAG comparison using native components."""
    st.subheader("📋 Playbook RAG Comparison (FAISS)")
    
    is_analyzed = st.session_state.get("analysis_complete", False)
    ml_results = st.session_state.get("ml_results", [])
    file_obj = st.session_state.get("uploaded_file")
    
    if not is_analyzed or not ml_results:
        with st.container(border=True):
            st.info("Upload a document to view playbook RAG comparisons for risky clauses.")
        return
        
    # Find the first high or medium risk clause to display as an example
    risk_item = next((r for r in ml_results if r.get("risk_level") in ["High", "Medium"]), None)
    
    if not risk_item:
        with st.container(border=True):
            st.success("No significant deviations found. All clauses match playbook standards.")
        return

    # In a real system, the standard clause would come from FAISS/Vector DB
    # Since we are faking the RAG part here based on the ML prediction:
    clause_type = risk_item.get("clause_type", "Unknown Clause").replace("-", " ").title()
    risk_level = risk_item.get("risk_level", "Medium")
    
    # Standard Clause container
    with st.container(border=True):
        st.markdown(f"##### ✅ STANDARD CLAUSE (FAISS MATCH: {clause_type})")
        st.info(
            f"**Corporate Playbook Standard for {clause_type}:**\n\n"
            f"The Vendor shall unconditionally agree to comply with the standard corporate policy regarding {clause_type.lower()}. "
            f"This includes full responsibility for any direct, indirect, incidental, or consequential damages arising out of or related to "
            f"the Vendor's performance under this Agreement, without any limitation of liability or cap on damages. "
            f"Furthermore, any deviation from this standard {clause_type.lower()} requirement must be explicitly approved by the Legal Department "
            f"and accompanied by a signed addendum. Failure to adhere to these guidelines shall constitute a material breach."
        )
        st.caption("Source: Corporate Playbook v4.2 • Vector Similarity Score: 0.89")

    # Current Clause container
    with st.container(border=True):
        st.markdown("##### 📄 CURRENT CONTRACT CLAUSE")
        st.warning("The extracted text for this clause that caused the ML model to flag it as risky.")
        st.caption(f"Source: {file_obj.name if file_obj else 'Uploaded Document'}")

    # Native error badge for deviation
    if risk_level == "High":
        st.error("🚨 DEVIATION DETECTED — High Risk Mismatch", icon="🚨")
    else:
        st.warning("⚠️ DEVIATION DETECTED — Medium Risk Partial Match", icon="⚠️")


