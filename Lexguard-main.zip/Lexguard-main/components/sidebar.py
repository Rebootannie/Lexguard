"""Sidebar component using true Streamlit native components."""
import streamlit as st


def render():
    """Render the sidebar with native Streamlit components."""
    with st.sidebar:
        st.markdown("## 🛡️ LEXGUARD AI")
        st.caption("Contract Intelligence Platform")
        st.divider()

        st.subheader("📄 Upload Contract")

        uploaded_file = st.file_uploader(
            "Upload Contract PDF / Scanned Image",
            type=["pdf", "png", "jpg", "jpeg", "tiff"],
            label_visibility="collapsed"
        )

        if uploaded_file:
            st.success(f"✅ {uploaded_file.name}")
            st.session_state["uploaded_file"] = uploaded_file

        st.write("")

        analyze_clicked = st.button("⚡ Analyze Document", type="primary", use_container_width=True)

        if analyze_clicked and uploaded_file:
            with st.spinner("Extracting text..."):
                from backend.pdf_extract import extract_text_from_pdf
                paragraphs = extract_text_from_pdf(uploaded_file.read())
                uploaded_file.seek(0)  # Reset for re-reads
                st.session_state["extracted_paragraphs"] = paragraphs

            with st.spinner("Running ML inference..."):
                from backend.ml.inference import analyze_contract_text
                results = analyze_contract_text(paragraphs[:10])  # Top 10 paragraphs
                st.session_state["ml_results"] = results

            st.session_state["analysis_complete"] = True
            
            # Increment document count
            if "total_documents_analyzed" not in st.session_state:
                st.session_state["total_documents_analyzed"] = 0
            st.session_state["total_documents_analyzed"] += 1
            
            st.success("✅ Analysis complete!")

        elif analyze_clicked and not uploaded_file:
            st.warning("Upload a document first.")

        st.divider()

        st.markdown("#### RECENT ACTIVITY")
        if st.session_state.get("analysis_complete"):
            file_obj = st.session_state.get("uploaded_file")
            if file_obj:
                st.caption(f"✅ {file_obj.name} analyzed")
        else:
            st.caption("No recent activity.")

        st.divider()
        st.caption("v3.0.0 • ML Engine Integration")
