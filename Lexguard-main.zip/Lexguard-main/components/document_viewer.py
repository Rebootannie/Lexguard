"""Document viewer component using native Streamlit containers."""
import streamlit as st

def render():
    """Render the scanned document panel using st.container."""
    st.subheader("📄 Scanned Document (OCR Active)")
    
    is_analyzed = st.session_state.get("analysis_complete", False)
    paragraphs = st.session_state.get("extracted_paragraphs", [])
    ml_results = st.session_state.get("ml_results", [])
    file_obj = st.session_state.get("uploaded_file")
    
    if not is_analyzed or not paragraphs:
        with st.container(border=True):
            st.info("Upload a document from the sidebar to view its text here.")
        return

    with st.container(border=True):
        # Native columns for header
        col1, col2 = st.columns([3, 1])
        with col1:
            st.success("🟢 OCR Active • Document Processed", icon="✅")
        with col2:
            st.caption(f"Filename: {file_obj.name}" if file_obj else "")
        
        st.divider()

        # Iterate through paragraphs and apply dynamic highlights
        for i, raw_text in enumerate(paragraphs):
            # Truncate text so it doesn't take up the whole screen
            text = raw_text.replace('\n', ' ')
            if len(text) > 150:
                text = text[:150] + "..."
                
            # Check if this paragraph was processed and has a risk
            risk = "None"
            if i < len(ml_results):
                risk = ml_results[i].get("risk_level", "None")
                
            if risk == "High":
                st.markdown(f"""
                <span style="background-color: rgba(214, 39, 40, 0.2); padding: 4px; border-radius: 4px; border: 1px solid #d62728; display: block; margin-bottom: 12px;">
                {text}
                </span>
                """, unsafe_allow_html=True)
            elif risk == "Medium":
                st.markdown(f"""
                <span style="background-color: rgba(255, 165, 0, 0.2); padding: 4px; border-radius: 4px; border: 1px solid #e67e22; display: block; margin-bottom: 12px;">
                {text}
                </span>
                """, unsafe_allow_html=True)
            elif risk == "Standard":
                st.markdown(f"""
                <span style="background-color: rgba(31, 119, 180, 0.1); padding: 4px; border-radius: 4px; border: 1px solid rgba(31,119,180,0.5); display: block; margin-bottom: 12px;">
                {text}
                </span>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"<div style='margin-bottom: 12px;'>{text}</div>", unsafe_allow_html=True)

        st.divider()
        st.caption("Legend: 🟦 Standard Clause | 🟧 Medium Risk | 🟥 High Risk")
