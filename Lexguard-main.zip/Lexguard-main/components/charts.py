"""Plotly charts — Risk Category Distribution bar chart and Compliance gauge."""
import streamlit as st
import plotly.graph_objects as go


def render_risk_chart():
    """Render the Risk Category Distribution bar chart."""
    st.subheader("📊 Risk Category Distribution")
    
    is_analyzed = st.session_state.get("analysis_complete", False)
    ml_results = st.session_state.get("ml_results", [])
    
    categories = ["Liability", "Indemnity", "IP Rights", "Term", "Confidentiality", "Data Privacy"]
    deviation_counts = [0, 0, 0, 0, 0, 0]
    
    if is_analyzed and ml_results:
        # Dynamically calculate deviations based on extracted clauses
        # Map some common clauses to categories
        for r in ml_results:
            if r.get("risk_level") in ["High", "Medium"]:
                c_type = r.get("clause_type", "").lower()
                if "liability" in c_type or "cap" in c_type:
                    deviation_counts[0] += 1
                elif "indemn" in c_type:
                    deviation_counts[1] += 1
                elif "ip" in c_type or "intellectual" in c_type:
                    deviation_counts[2] += 1
                elif "term" in c_type:
                    deviation_counts[3] += 1
                elif "confidential" in c_type:
                    deviation_counts[4] += 1
                else:
                    # Put unmapped deviations in Data Privacy for now
                    deviation_counts[5] += 1

    # Standard professional colors
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]

    fig = go.Figure()

    fig.add_trace(go.Bar(
        x=categories,
        y=deviation_counts,
        marker=dict(
            color=colors,
            line=dict(color="rgba(255,255,255,0.1)", width=1),
            cornerradius=4
        ),
        text=deviation_counts if sum(deviation_counts) > 0 else ["" for _ in categories],
        textposition="outside",
        textfont=dict(size=13, family="sans serif"),
        hovertemplate="<b>%{x}</b><br>Deviations: %{y}<extra></extra>"
    ))

    fig.update_layout(
        margin=dict(l=40, r=20, t=20, b=60),
        xaxis=dict(
            tickfont=dict(size=12, family="sans serif"),
            showgrid=False,
            showline=False,
        ),
        yaxis=dict(
            tickfont=dict(size=12, family="sans serif"),
            showgrid=True,
            gridcolor="rgba(128,128,128,0.2)",
            showline=False,
            title=dict(text="Deviations Found", font=dict(size=12)),
            # If max count is 0, set range to 1 to avoid weird scaling
            range=[0, max(max(deviation_counts) + 1, 5)] if sum(deviation_counts) > 0 else [0, 5]
        ),
        hoverlabel=dict(
            font_size=13,
            font_family="sans serif",
        ),
        bargap=0.3,
        height=340,
    )

    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    
    if not is_analyzed:
        st.info("Upload a document to view risk distributions.")
