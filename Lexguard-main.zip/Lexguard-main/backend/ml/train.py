import os
import glob
import pandas as pd
import torch
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from sklearn.model_selection import train_test_split

# Setup paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "archive")
MODEL_DIR = os.path.join(BASE_DIR, "backend", "models", "contract-classifier")

# Select a subset of important clauses to classify
TARGET_CLAUSES = [
    "indemnification",
    "termination",
    "governing-law",
    "liability",
    "confidentiality",
    "warranties"
]

def load_data():
    """Load and combine the target CSVs from the dataset."""
    print("Loading datasets...")
    dataframes = []
    
    for clause in TARGET_CLAUSES:
        csv_path = os.path.join(DATA_DIR, f"{clause}.csv")
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
            if 'clause_text' in df.columns and 'clause_type' in df.columns:
                df = df[['clause_text', 'clause_type']].dropna()
                
                # Limit samples per class to save storage and time (e.g., max 400 per class)
                if len(df) > 400:
                    df = df.sample(400, random_state=42)
                
                dataframes.append(df)
        else:
            print(f"Warning: {csv_path} not found.")

    if not dataframes:
        raise ValueError("No data found! Check dataset path.")

    full_df = pd.concat(dataframes, ignore_index=True)
    
    # Map labels to integers
    label_map = {label: i for i, label in enumerate(TARGET_CLAUSES)}
    full_df['label'] = full_df['clause_type'].map(label_map)
    
    # Drop rows that didn't map correctly
    full_df = full_df.dropna(subset=['label'])
    full_df['label'] = full_df['label'].astype(int)
    
    print(f"Total samples loaded after capping: {len(full_df)}")
    return full_df, label_map

def main():
    df, label_map = load_data()
    
    # Split into train and validation
    train_df, val_df = train_test_split(df, test_size=0.1, random_state=42, stratify=df['label'])
    
    # Convert to Hugging Face Dataset
    train_dataset = Dataset.from_pandas(train_df)
    val_dataset = Dataset.from_pandas(val_df)
    
    model_name = "distilbert-base-uncased"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    def tokenize_function(examples):
        return tokenizer(examples["clause_text"], padding="max_length", truncation=True, max_length=128)
    
    print("Tokenizing datasets...")
    tokenized_train = train_dataset.map(tokenize_function, batched=True)
    tokenized_val = val_dataset.map(tokenize_function, batched=True)
    
    num_labels = len(TARGET_CLAUSES)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)
    
    # Check if GPU is available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on device: {device}")
    model.to(device)
    
    training_args = TrainingArguments(
        output_dir=MODEL_DIR,
        eval_strategy="epoch",
        learning_rate=2e-5,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=16,
        num_train_epochs=3,
        weight_decay=0.01,
        save_strategy="epoch",
        load_best_model_at_end=False,  # Disabled: Windows paging file crashes when reloading large model
        save_total_limit=1,  # CRITICAL: Ensures we don't run out of storage! Only keeps 1 checkpoint.
        fp16=torch.cuda.is_available(), # Use mixed precision if GPU is available
    )
    
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_val,
        processing_class=tokenizer,
    )
    
    print("Starting training...")
    trainer.train()
    
    print(f"Saving final model to {MODEL_DIR}")
    trainer.save_model(MODEL_DIR)
    
    # Save label mapping for inference
    import json
    with open(os.path.join(MODEL_DIR, "label_map.json"), "w") as f:
        json.dump({v: k for k, v in label_map.items()}, f)

if __name__ == "__main__":
    main()
