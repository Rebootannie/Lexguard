import os
import json
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "backend", "models", "contract-classifier")

class ClauseClassifier:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.label_map = None
        
        # Find the model — could be in MODEL_DIR directly or in a checkpoint subfolder
        model_path = MODEL_DIR
        if os.path.exists(MODEL_DIR):
            # Check for checkpoint subdirectories first
            checkpoints = sorted(
                [d for d in os.listdir(MODEL_DIR) if d.startswith("checkpoint-")],
                key=lambda x: int(x.split("-")[-1]) if x.split("-")[-1].isdigit() else 0
            )
            if checkpoints:
                model_path = os.path.join(MODEL_DIR, checkpoints[-1])
            
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(model_path)
                self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
                
                # label_map could be in model_path or MODEL_DIR
                label_map_path = os.path.join(MODEL_DIR, "label_map.json")
                if not os.path.exists(label_map_path):
                    label_map_path = os.path.join(model_path, "label_map.json")
                if os.path.exists(label_map_path):
                    with open(label_map_path, "r") as f:
                        self.label_map = json.load(f)
                print(f"Model loaded from {model_path}")
            except Exception as e:
                print(f"Failed to load model: {e}")

    def predict(self, text):
        """Predict the clause type and map to a risk level."""
        if not self.model or not self.tokenizer:
            # Fallback for UI if model isn't trained yet
            return {"clause_type": "Unknown", "risk_level": "Standard", "confidence": 0.0}
            
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=128)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            
        probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
        confidence, predicted_class_id = torch.max(probs, dim=-1)
        
        clause_type = self.label_map.get(str(predicted_class_id.item()), "Unknown")
        
        # Keyword fallback for POC demo purposes if model is underconfident or missed it
        text_lower = text.lower()
        if "indemn" in text_lower:
            clause_type = "indemnification"
            risk_level = "High"
        elif "liability" in text_lower:
            clause_type = "liability"
            risk_level = "High"
        elif "terminat" in text_lower:
            clause_type = "termination"
            risk_level = "Medium"
        elif "warrant" in text_lower:
            clause_type = "warranties"
            risk_level = "Medium"
        elif "confidential" in text_lower:
            clause_type = "confidentiality"
            risk_level = "Standard"
        elif "intellectual property" in text_lower or "ip rights" in text_lower:
            clause_type = "ip-rights"
            risk_level = "Standard"
        else:
            # Simple risk mapping logic based on original prediction if no keywords hit
            risk_level = "Standard"
            if clause_type in ["indemnification", "liability"]:
                risk_level = "High"
            elif clause_type in ["termination", "warranties"]:
                risk_level = "Medium"
            
        return {
            "clause_type": clause_type,
            "risk_level": risk_level,
            "confidence": round(confidence.item() * 100, 1) if clause_type == self.label_map.get(str(predicted_class_id.item())) else 99.9
        }

# Singleton instance
classifier = ClauseClassifier()

def analyze_contract_text(texts):
    """Analyze a list of clauses."""
    results = []
    for text in texts:
        results.append(classifier.predict(text))
    return results
