"""PDF text extraction utility."""
import io
import re

def extract_text_from_pdf(file_bytes):
    """Extract text from uploaded PDF bytes. Returns list of clause-like paragraphs."""
    try:
        import pdfplumber
        paragraphs = []
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    # Real PDFs often have \n for line breaks and \n\n for paragraph breaks
                    # Split by 2 or more newlines (paragraph break)
                    parts = re.split(r'\n\s*\n', text)
                    for p in parts:
                        # Join lines within the same paragraph
                        clean = p.replace('\n', ' ').strip()
                        # Clean up multiple spaces
                        clean = re.sub(r'\s+', ' ', clean)
                        
                        if len(clean) > 40:  # Skip very short lines/headers/page numbers
                            paragraphs.append(clean)
        return paragraphs
    except Exception as e:
        return [f"Error extracting text: {e}"]
