"""
Section 3: Analytics & Compliance
Renders the bottom row — Plotly risk distribution bar chart,
compliance gauge, and RAG/Playbook comparison panel.
"""
import streamlit as st
from components import charts, playbook


def render():
    """Render Section 3 — Charts + Playbook RAG side-by-side."""
    st.subheader("Analytics & Compliance")

    col_chart, col_playbook = st.columns([1, 1], gap="medium")

    with col_chart:
        charts.render_risk_chart()

    with col_playbook:
        playbook.render()
