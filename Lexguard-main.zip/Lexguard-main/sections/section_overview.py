"""
Section 1: Dashboard Overview
Renders the top-row KPI metric cards — Total Contracts, High Risk Deviations,
and Average Compliance Score with a mini Plotly gauge.
"""
import streamlit as st
from components import metrics


def render():
    """Render Section 1 — Dashboard Overview with 3 KPI metric cards."""
    metrics.render()
    st.markdown("<div style='height: 24px;'></div>", unsafe_allow_html=True)
