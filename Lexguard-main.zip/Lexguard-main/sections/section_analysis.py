"""
Section 2: Contract Analysis
Renders the dual-panel middle row — OCR Document Viewer (left)
and AI Clause Extraction with Risk Flags (right).
"""
import streamlit as st
from components import document_viewer, clause_extraction


def render():
    """Render Section 2 — Document viewer + AI clause extraction side-by-side."""
    st.subheader("Contract Analysis")
    
    file_obj = st.session_state.get("uploaded_file")
    if file_obj:
        st.caption(f"Analyzing: {file_obj.name}")
    else:
        st.caption("Awaiting document upload...")

    # Render AI Clause Extraction (Outputs) at the top
    clause_extraction.render()

    st.markdown("<div style='height: 24px;'></div>", unsafe_allow_html=True)
    st.divider()
    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

    # Render Document Scan (Source Document) at the bottom
    document_viewer.render()

    st.markdown("<div style='height: 24px;'></div>", unsafe_allow_html=True)
