# Sections package — Each file renders one major dashboard section
